// Bu dosya, uygulamanın arka planda çalışmasını sağlayan özel servis çalışanıdır.
// OneSignal bildirimlerinin uygulama kapalıyken bile alınmasını ve gösterilmesini sağlar.

importScripts('https://cdn.onesignal.com/sdks/web/v16/OneSignalSDK.sw.js');
