// Bu dosyanın içeriği, bildirim sistemi yeniden yapılandırıldığı için
// next.config.js dosyasına taşınmıştır. Artık bu dosyaya ihtiyaç yoktur
// ve derleme sırasında PWA eklentisi tarafından otomatik olarak oluşturulacaktır.
