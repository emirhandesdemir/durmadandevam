// Bu dosya, kaldırılan "Hızlı Eşleşme" özelliğiyle ilgili olduğu için artık kullanılmamaktadır ve güvenle silinebilir.
