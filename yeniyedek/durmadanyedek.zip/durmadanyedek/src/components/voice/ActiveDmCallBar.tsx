// src/components/voice/ActiveDmCallBar.tsx
// This component has been disabled from the UI.
export default function ActiveDmCallBar() {
    return null;
}
