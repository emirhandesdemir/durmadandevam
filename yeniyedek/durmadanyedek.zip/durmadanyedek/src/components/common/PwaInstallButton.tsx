// Bu bileşenin içeriği, kod tekrarını azaltmak amacıyla `src/app/page.tsx` dosyasına taşınmıştır.
// Bu dosya artık kullanılmamaktadır ve güvenle silinebilir.
