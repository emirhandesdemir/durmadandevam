// src/components/common/IncomingCallManager.tsx
// This component has been disabled from the UI.
export default function IncomingCallManager() {
  return null;
}
