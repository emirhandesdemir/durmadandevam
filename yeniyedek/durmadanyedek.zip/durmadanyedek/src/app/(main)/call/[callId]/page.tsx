// src/app/(main)/call/[callId]/page.tsx
// This page is intentionally left blank as the feature has been disabled from the UI.
export default function CallPage() {
  return null;
}
