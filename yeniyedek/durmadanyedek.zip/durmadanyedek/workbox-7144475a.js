// Bu dosya, eski servis çalışanı yapılandırmasından kalan bir artık dosyadır ve artık kullanılmamaktadır.
// Çakışmaları önlemek için içeriği temizlenmiştir ve güvenle silinebilir.
