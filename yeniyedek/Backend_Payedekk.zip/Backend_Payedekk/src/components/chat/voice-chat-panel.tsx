// Bu bileşen artık kullanılmamaktadır. Sesli sohbet işlevselliği
// `VoiceChatProvider` ve ilgili hook'lar tarafından global olarak yönetilmektedir.
// Karışıklığı önlemek için içeriği temizlenmiştir ve güvenle silinebilir.
