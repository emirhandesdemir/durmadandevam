// Bu dosya artık kullanılmamaktadır. Oda oluşturma mantığı
// `src/components/rooms/CreateRoomForm.tsx` dosyasına taşınmıştır.
// Karışıklığı önlemek için içeriği temizlenmiştir ve güvenle silinebilir.
