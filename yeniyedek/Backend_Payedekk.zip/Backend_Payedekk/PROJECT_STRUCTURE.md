# Proje Yapısı (BİLGİLENDİRME)

Bu proje yapısı artık geçerli değildir.

**Tüm dosyalar projenin ana dizinine taşınmıştır.** Gelecekteki tüm işlemler ana dizin üzerinden yapılacaktır. Bu klasör (`Backend_Payedekk`) artık güncel değildir ve içeriği göz ardı edilebilir.
