// Bu bileşen, uygulamanın yalnızca PWA (ana ekrana eklenmiş uygulama)
// olarak kullanılmasını zorunlu kılmak için tasarlanmıştı.
// Ancak kullanıcı isteği üzerine bu zorunluluk kaldırıldığı için
// bu bileşen artık projede kullanılmamaktadır ve silinebilir.
