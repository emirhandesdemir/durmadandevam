// Bu dosya artık kullanılmamaktadır. Odalar sayfası mantığı
// `src/app/(main)/rooms/page.tsx` dosyasına taşınmıştır.
// Karışıklığı önlemek için içeriği temizlenmiştir ve güvenle silinebilir.
