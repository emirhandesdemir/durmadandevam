// Bu bileşenin içeriği, kod tekrarını azaltmak amacıyla `src/app/(main)/layout.tsx` dosyasına taşınmıştır.
// Bu dosya artık kullanılmamaktadır ve güvenle silinebilir.
