// Bu bileşen, kullanıcı isteği üzerine kaldırılmıştır ve artık kullanılmamaktadır.
// Projedeki ilgili çağrılar (main layout dosyasından) temizlenmiştir.
// Bu dosya güvenle silinebilir.
