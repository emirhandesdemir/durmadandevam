// src/app/signup/SignUpPageContent.tsx
// Bu bileşenin içeriği, kod tekrarını azaltmak amacıyla `src/app/signup/page.tsx` dosyasına taşınmıştır.
// Bu dosya artık kullanılmamaktadır ve güvenle silinebilir.
