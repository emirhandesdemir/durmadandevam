// Bu dosya, kaldırılan "Keşfet" özelliğiyle ilgili olduğu için artık kullanılmamaktadır ve güvenle silinebilir.
